import { addWatchedRange, lessonKey } from "./progress.js";

const site = "https://seif-study-os.vercel.app";
const prefix = "lesson:";
const tasks = new Map();

chrome.runtime.onInstalled.addListener(() => {
  void chrome.tabs.query({ url: site + "/*" }).then(tabs =>
    Promise.allSettled(tabs.map(tab =>
      chrome.scripting.executeScript({ target: { tabId: tab.id }, files: ["bridge.js"] })
    ))).catch(() => {});
});

function onLesson(key, action) {
  const pending = tasks.get(key) ?? Promise.resolve();
  const next = pending.catch(() => {}).then(async () => {
    const id = prefix + key;
    const data = (await chrome.storage.local.get(id))[id] ?? { ranges: [], watched: 0, manual: 0, notes: [] };
    return action(data, id);
  });
  tasks.set(key, next);
  const clean = () => { if (tasks.get(key) === next) tasks.delete(key); };
  next.then(clean, clean);
  return next;
}

chrome.runtime.onMessage.addListener((message, sender, respond) => {
  handle(message, sender).then(respond, () => respond({ error: "تعذّر حفظ بيانات الدرس." }));
  return true;
});

async function handle(message, sender) {
  if (!message || !sender.url) return null;
  const extensionPage = sender.url === chrome.runtime.getURL("popup.html");
  const studySite = new URL(sender.url).origin === site;
  if (studySite && message.type === "activities") {
    const all = await chrome.storage.local.get(null);
    const now = Date.now();
    return Object.entries(all)
      .filter(([id, value]) => id.startsWith(prefix) && (value.manualSince || now - (value.updatedAt ?? 0) < 60000))
      .map(([id, { title, position, lastAutoAt, lastPlayingAt, playing, manualSince, manualChangedAt, updatedAt }]) =>
        ({ url: id.slice(prefix.length), title, position, lastAutoAt, lastPlayingAt, playing, manualSince, manualChangedAt, updatedAt }))
      .sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 30);
  }
  const key = lessonKey(extensionPage || studySite ? message.url : sender.tab?.url || sender.url);
  if (!key) return null;
  if (studySite && message.type === "list") {
    const host = new URL(key).hostname.replace(/^www\./, "");
    const all = await chrome.storage.local.get(null);
    return Object.entries(all).filter(([id, value]) => id.startsWith(prefix)
      && (value.position !== undefined || value.watched > 0 || value.manual > 0 || value.manualSince || value.notes?.length))
      .flatMap(([id, value]) => {
        const url = id.slice(prefix.length);
        const normalized = lessonKey(url);
        if (!normalized) return [];
        const hostname = new URL(normalized).hostname.replace(/^www\./, "");
        if (hostname !== host && !hostname.endsWith("." + host)) return [];
        return [{ url: normalized, title: value.title || new URL(normalized).pathname, position: value.position, lastPlayingAt: value.lastPlayingAt, playing: value.playing, lastAutoAt: value.lastAutoAt, manualSince: value.manualSince, updatedAt: value.updatedAt ?? value.lastAutoAt ?? value.manualSince ?? 0 }];
      }).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 30);
  }
  if (studySite && message.type === "sync-status") {
    const status = message.status;
    if (!status || !["linked", "paused", "break", "conflict", "unknown", "choose", "error"].includes(status.state)
        || typeof status.subject !== "string" || status.subject.length > 80) return null;
    await chrome.storage.local.set({ ["sync:" + key]: {
      state: status.state, subject: status.subject,
      subjectKey: /^[a-z_]{1,20}$/.test(status.subjectKey) ? status.subjectKey : "",
      timer: [status.timer?.seconds, status.timer?.startedAt, status.timer?.deadline].every(Number.isFinite) ? status.timer : undefined,
      at: Date.now(),
    } });
    return true;
  }
  if (studySite && message.type !== "read") return null;
  if (!extensionPage && !studySite) {
    if (message.type !== "sample" || !sender.tab?.url) return null;
    const pattern = new URL(key).origin + "/*";
    if (!await chrome.permissions.contains({ origins: [pattern] })) return null;
  }
  return onLesson(key, async (data, id) => {
    const now = Date.now();
    if (message.type === "read") {
      const statusKey = "sync:" + key;
      const status = extensionPage ? (await chrome.storage.local.get(statusKey))[statusKey] : undefined;
      return { ...data, status, manual: data.manual + (data.manualSince ? Math.floor((now - data.manualSince) / 1000) : 0) };
    }
    if (message.type === "sample") {
      if (!Number.isFinite(message.position) || message.position < 0 || message.position > 604800) return null;
      data.position = message.position;
      if (typeof sender.tab?.title === "string") data.title = sender.tab.title.trim().slice(0, 160);
      data.lastAutoAt = now;
      data.playing = message.playing === true;
      if (data.playing) data.lastPlayingAt = now;
      if (Number.isFinite(message.from) && message.from >= 0 && message.position - message.from <= 30
          && Number.isFinite(message.seconds) && message.seconds > 0 && message.seconds <= 5 && !data.manualSince) {
        data.lastPlayingAt = now;
        data.ranges = addWatchedRange(data.ranges, message.from, message.position);
        if (!data.lastCountAt || now - data.lastCountAt >= message.seconds * 700) {
          data.watched += message.seconds;
          data.lastCountAt = now;
        }
      }
    } else if (message.type === "manual") {
      data.manualChangedAt = now;
      if (data.manualSince) {
        data.manual += Math.floor((now - data.manualSince) / 1000);
        delete data.manualSince;
      } else {
        data.manualSince = now;
      }
    } else if (message.type === "bookmark") {
      if (!Number.isFinite(message.position) || message.position < 0 || message.position > 604800) return null;
      data.position = message.position;
    } else if (message.type === "note") {
      const text = typeof message.text === "string" ? message.text.trim().slice(0, 1000) : "";
      if (!text) return null;
      data.notes.push({ text, position: data.position ?? null, at: now });
    } else {
      return null;
    }
    if (extensionPage && typeof message.title === "string" && message.title.trim()) data.title = message.title.trim().slice(0, 160);
    data.updatedAt = now;
    await chrome.storage.local.set({ [id]: data });
    return data;
  });
}
